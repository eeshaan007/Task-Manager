package com.eeshaangupta.lab5;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ActivityAddTask extends AppCompatActivity {
    // Declaring all the buttons and widgets.
    private EditText taskName;
    private EditText taskDescription;
    private Button btnAddTask;
    private TextView taskInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);
        taskName = findViewById(R.id.task_name);
        taskDescription = findViewById(R.id.task_description);
        btnAddTask = findViewById(R.id.button_add_task);
        taskInfo = findViewById(R.id.task_info);
        btnAddTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Convert EditText values into Strings.
                String taskname = taskName.getText().toString();
                String taskdescription = taskDescription.getText().toString();
                // Validate EditText values for Empty Strings and Mismatch Values.
                if(taskname.isEmpty()){
                    taskName.setError(getResources().getString(R.string.task_name_error));
                } else if(taskdescription.isEmpty()){
                    taskDescription.setError(getResources().getString(R.string.task_description_error));
                } else {
                    taskInfo.setText(String.format(getResources().getString(R.string.task_added),taskname.toUpperCase()));
                    // Clearing/Removing EditText contents to Blank State.
                    taskName.getText().clear();
                    taskDescription.getText().clear();
                    // Call function to Save Task using TaskManager.
                    addTask(taskname,taskdescription);
                }
            }
        });
    }

    /**
     * Functionality to Add/Save Task using TaskManager Class
     */

    public void addTask(String name, String description){
        TaskManager taskManager = new TaskManager(this);
        Task task = new Task();
        task.setName(name);
        task.setCompleted(false);
        task.setDescription(description);
        taskManager.addTask(task);
    }

    /**
     * Functionality for going back in the app
     * on pressing back button.
     */
    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
