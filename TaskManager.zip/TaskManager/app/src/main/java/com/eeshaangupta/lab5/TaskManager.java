package com.eeshaangupta.lab5;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class TaskManager{
    //Declare contant and common values
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private static String 	TASK_LIST = "task_list";

    public TaskManager(Context context){
        String PREF_NAME = "shared_prefrences";
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    /**
     * Functionality to Save Task in shared preferences
     */

    public void addTask(Task task){
        ArrayList<Task> taskList;
        //Using GSON library to convert Task object to json string for saving in shared preferences
        Gson gson = new Gson();
        String tasklistString = sharedPreferences.getString(TASK_LIST,"");
        if(tasklistString.isEmpty()){
            //Shared Preference is Empty, Create fresh Array List
            taskList = new ArrayList<>();
            taskList.add(task);
            String json = gson.toJson(taskList);
            //Now save JSON String in shared preferences
            editor = sharedPreferences.edit();
            editor.putString(TASK_LIST, json);
            editor.apply();
        } else {
            //Shared Preference is Not Empty, Add to existing Array List
            taskList = gson.fromJson(tasklistString, ArrayList.class);
            taskList.add(task);
            String json = gson.toJson(taskList);
            editor = sharedPreferences.edit();
            editor.putString(TASK_LIST, json);
            editor.apply();
        }
    }

    /**
     * Functionality to Remove a given Task from Shared Preferences
     */
    public void removeTask(int index){
        ArrayList<Task> taskList;
        Gson gson = new Gson();
        String jsonString = sharedPreferences.getString(TASK_LIST,"");
        Type type = new TypeToken<ArrayList<Task>>(){}.getType();
        taskList = gson.fromJson(jsonString, type);
        taskList.remove(index);
        String json = gson.toJson(taskList);
        editor = sharedPreferences.edit();
        editor.putString(TASK_LIST, json);
        editor.apply();
    }

    /**
     * Functionality to get list of All Tasks from Shared Preferences
     */
    public ArrayList<Task> getAllTasks(){
        ArrayList<Task> taskList;
        Gson gson = new Gson();
        String jsonString = sharedPreferences.getString(TASK_LIST,"");
        Type type = new TypeToken<ArrayList<Task>>(){}.getType();
        taskList = gson.fromJson(jsonString, type);
        return taskList;
    }

}
