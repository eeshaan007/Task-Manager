package com.eeshaangupta.lab5;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ActivityRemoveTask extends AppCompatActivity {
    // Declaring all the buttons and widgets.
    private ListView listView;
    private TextView noTaskError;
    private ArrayList<Task> taskList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_task);
        listView = findViewById(R.id.listView);
        noTaskError = findViewById(R.id.no_task_error);
        taskList = getAllTasks();
        //Check if tasks available
        if(taskList.size()>0){
            TaskArrayAdapter adapter = new TaskArrayAdapter(this,taskList);
            listView.setAdapter(adapter);
        } else {
            //Show Message if Task List is empty
            noTaskError.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Functionality to fetch all Tasks saved in SharedPreferences using TaskManager
     */
    public ArrayList<Task> getAllTasks(){
        TaskManager taskManager = new TaskManager(this);
        return  taskManager.getAllTasks();
    }

    /**
     * Functionality to remove task by index in SharedPreferences using TaskManager
     */
    public void removeTask(int index){
        TaskManager taskManager = new TaskManager(this);
        taskManager.removeTask(index);
    }

    /**
     * Custom ArrayAdapter to populate Tasks item in custom layout
     */

    public class TaskArrayAdapter extends ArrayAdapter<Task> {
        private final Context context;
        private final ArrayList<Task> values;

        public TaskArrayAdapter(Context context, ArrayList<Task> values) {
            super(context, -1, values);
            this.context = context;
            this.values = values;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View rowView = inflater.inflate(R.layout.task_item_layout, parent, false);
            TextView itemTaskName = rowView.findViewById(R.id.task_name);
            TextView itemTaskDescription = rowView.findViewById(R.id.task_description);
            TextView itemTaskTaskStatus = rowView.findViewById(R.id.task_status);
            Button btnRemoveTask = rowView.findViewById(R.id.delete_task);
            //Set Task item values in list item
            itemTaskName.setText(values.get(position).getName());
            itemTaskDescription.setText(values.get(position).getDescription());
            itemTaskTaskStatus.setText(values.get(position).getCompleted().toString());
            btnRemoveTask.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String taskname = values.get(position).getName();
                    removeTask(position);
                    //Remove task from visible list and refresh items
                    taskList.remove(position);
                    notifyDataSetChanged();
                    //Toast to confirm Item removal
                    Toast.makeText(ActivityRemoveTask.this,String.format(getResources().getString(R.string.task_removed),taskname),Toast.LENGTH_SHORT).show();
                    if(taskList.size()==0){
                        //Show Message if Task List is now empty
                        noTaskError.setVisibility(View.VISIBLE);
                    }
                }
            });
            return rowView;
        }
    }

    /**
     * Functionality for going back in the app
     * on pressing back button.
     */
    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
