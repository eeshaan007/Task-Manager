package com.eeshaangupta.lab5;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ActivityTaskMenu extends AppCompatActivity implements View.OnClickListener {
    // Declaring all the buttons and widgets.
    private Button btnAddTask;
    private Button btnDeleteTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_menu);
        btnAddTask = findViewById(R.id.add_task);
        btnDeleteTask = findViewById(R.id.delete_task);
        btnAddTask.setOnClickListener(this);
        btnDeleteTask.setOnClickListener(this);
    }


    /**
     * Common Click Listner
     * for handling OnClick events.
     */
    @Override
    public void onClick(View view) {
        int id = view.getId();
        //Using switch for handling clicks on different button id's
        switch (id){
            case R.id.add_task:
                Intent addTask = new Intent(ActivityTaskMenu.this, ActivityAddTask.class);
                startActivity(addTask);
                break;
            case R.id.delete_task:
                Intent deleteTask = new Intent(ActivityTaskMenu.this, ActivityRemoveTask.class);
                startActivity(deleteTask);
                break;
        }
    }

    /**
     * Functionality for going back in the app
     * on pressing back button.
     */
    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
