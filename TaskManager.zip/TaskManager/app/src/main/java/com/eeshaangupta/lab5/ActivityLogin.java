package com.eeshaangupta.lab5;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ActivityLogin extends AppCompatActivity {
    // Declaring all the buttons and widgets.
    private EditText userName;
    private EditText userPassword;
    private Button buttonLogin;
    private String defaultUsername;
    private String defaultPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        userName = findViewById(R.id.user_name);
        userPassword = findViewById(R.id.password);
        // Get Default Username and Password from Strings.
        defaultUsername = getResources().getString(R.string.default_username);
        defaultPassword = getResources().getString(R.string.default_password);
        buttonLogin = findViewById(R.id.button_login);
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Convert EditText values into Strings.
                String username = userName.getText().toString();
                String password = userPassword.getText().toString();
                // Validate EditText values for Empty Strings and Mismatch Values.
                if(username.isEmpty()){
                    // Username String empty, show error
                    userName.setError(getResources().getString(R.string.username_error));
                } else if (password.isEmpty()){
                    // Password String empty, show error
                    userPassword.setError(getResources().getString(R.string.password_error));
                } else if(!username.contentEquals(defaultUsername)){
                    // Username String does not match default Username, show error Toast
                    Toast.makeText(ActivityLogin.this,getResources().getString(R.string.invalid_username),Toast.LENGTH_SHORT).show();
                } else if(!password.contentEquals(defaultPassword)){
                    // Password String does not match default Password, show error Toast
                    Toast.makeText(ActivityLogin.this,getResources().getString(R.string.invalid_password),Toast.LENGTH_SHORT).show();
                } else {
                    // Username Password match, Launch TaskMenu Activity
                    Intent taskMenuActivity = new Intent(ActivityLogin.this, ActivityTaskMenu.class);
                    startActivity(taskMenuActivity);
                }
            }
        });
    }

    /**
     * Functionality for closing app
     * on pressing back button.
     */
    @Override
    public void onBackPressed() {
        super.onBackPressed();

    }
}
